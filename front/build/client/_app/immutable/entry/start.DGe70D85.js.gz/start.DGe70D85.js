import{a as t}from"../chunks/entry.B-0cY56T.js";export{t as start};
